In Windows, execute run.bat
In Linux, execute run.sh
In Mac, two options:
1) execute run.app and select the file Representar.image
2) drag the file Representar.image and drop it on run.app