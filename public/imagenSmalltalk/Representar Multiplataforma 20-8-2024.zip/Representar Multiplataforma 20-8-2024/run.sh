#!/bin/bash
vm-jit/squeak Representar.image
