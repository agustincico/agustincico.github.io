#!/bin/bash
vm-jit/squeak Cuis5.0-4507.image
