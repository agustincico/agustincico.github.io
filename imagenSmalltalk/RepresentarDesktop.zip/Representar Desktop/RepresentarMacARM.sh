xattr -dr com.apple.quarantine *
./Representar.app/Contents/MacOS/Squeak RepresentarFiles/Representar.image