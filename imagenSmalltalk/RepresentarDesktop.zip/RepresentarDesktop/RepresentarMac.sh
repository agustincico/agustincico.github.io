cd "$(dirname "$0")"
xattr -dr com.apple.quarantine *
./RepresentarFiles/VirtualMachine.app/Contents/MacOS/Squeak RepresentarFiles/Representar.image